# ADAPTIVE-PATH — Progress and Session Continuity

Last updated: 2026-11-03 13:25 +0530  
Current branch: `research/phase-0-audit`  
Baseline tag/commit: `baseline-v0` (Git initial baseline commit `4538e6c`)  
Current phase: Phase 1 — Research Correctness & Empirical Validation (F4 Integrated & Tested)  
Deadline: 2026-11-15  

## Gate status
- G1 repository audit: **APPROVED** (2026-11-03 11:59)
- G2 research definitions: **APPROVED** (2026-11-03 13:10)
- G3 frozen-test run: NOT STARTED

## Completed
| Item | Evidence path/commit/test | Status |
|---|---|---|
| Step 0: Git repository initialization & safety | Initial commit `baseline-v0`, branch `research/phase-0-audit` | DONE |
| Step 1: Baseline test suite execution | 216 pytest passed (47.09s), 17 vitest passed (4.51s) | DONE |
| Step 2: Architecture inspection | Documented in `docs/AUDIT.md` | DONE |
| Step 3: Findings F1–F7 Verification | All 7 findings verified with file/line evidence in `docs/AUDIT.md` | DONE |
| Step 4: Dynamics Audit | Completed in `docs/DYNAMICS.md` | DONE |
| Step 5: Realistic Schedule to Nov 15 | Established in `docs/AUDIT.md` | DONE |
| Gate G1 User Sign-Off | Explicit user approval received | DONE |
| Phase 1 Step 1: Research Metric Definitions (v2.2) | Revised in `docs/METRICS.md` with exact 2D quadratic TTC & edge cases | DONE |
| Phase 1 Step 1: Formal Risk Field Definition (v2.3) | Revised in `docs/RISK_DEFINITION.md` with Mahalanobis conformal score/set consistency, episode-max aggregation & inference-time input parity | DONE |
| Phase 1 Step 1: Statistical Analysis Plan (v2.3) | Revised in `docs/SAP.md` with episode-level calibration scores, non-target exclusion, independent episode accounting, and inference input parity | DONE |
| Architecture & Decisions Record (v2.3) | Updated `docs/DECISIONS.md` with DEC-001 through DEC-023 | DONE |
| Gate G2 User Sign-Off | Explicit user approval received | DONE |
| Phase 1 Step 1: F4 Conformal Calibration Integration | `engine/prediction/conformal_calibrator.py`, `engine/prediction/predictor.py`, `tests/test_conformal_calibrator.py` (10/10 passed, 135/135 full suite passed) | DONE |
| Phase 1 Step 2: Workstream A — F4 Consumer Audit & Enforcement | Audited normalizers, feature parity, quantile bounds; enforced `coverage_guarantee_valid` across `engine/risk/field.py`, `engine/behaviour/state_machine.py`, `engine/planners/p2_risk_aware.py`, `engine/planners/p3_adaptive.py`; verified via unit tests | DONE |
| Phase 1 Step 2: Workstream B — Independent Calibration Artifact | Generated `engine/ml/models/conformal_tables.json` strictly on calibration split (Seeds 1500–1539, 40 seeds x 5 scenarios = 200 episodes); $n_e \ge 40$ for all 6 target classes; full audit provenance recorded | DONE |
| Phase 1 Step 2: Workstream C — Authoritative Metrics Consolidation | Resolved F1 (`ReplayView.tsx:146`), F2 (`CompareView.tsx:117-140`), and F7 (`engine/metrics.py`, `backend/app/adapters/pipeline/aggregator.py`); verified exact SAT, clearance, 2D TTC, filtered jerk, goal predicate (145/145 backend tests pass, 17/17 studio tests pass) | DONE |

## In progress
| Item | Owner/agent | Files | Next action | Blocker |
|---|---|---|---|---|
| Phase 1 Step 3: F3 Diagnosis & Correction Design | Antigravity | `engine/planners/`, `docs/F3_DIAGNOSIS.md` | Finalize mathematical design (persistence penalty, hypothesis weighting, risk kernel consistency) | Completed Step 3A; Awaiting G2/Step 3A approval |
| Workstream B: Demo Fallback Track | Antigravity | `studio/`, `scripts/` | Coordinated cattle-crossing fallback demo | Parallel workstream |

## Decisions made
| Date | Decision | Rationale | Approved by / gate |
|---|---|---|---|
| 2026-11-03 | Preserve untouched baseline as `baseline-v0` on `research/phase-0-audit` | Rule 5 repository safety | Standing Rules |
| 2026-11-03 | Audit findings F1–F7 without code modification in Phase 0 | Strict baseline integrity | Phase 0 Directive |
| 2026-11-03 | Formal G1 Approval received; authorized Workstreams A & B | User authorization | User / G1 |
| 2026-11-03 | Critical Ordering Rule: F4 calibration integration must precede F3 progress tuning | Conformal cones alter risk and replan triggers | DEC-004 / Phase 1 |
| 2026-11-03 | Five-way disjoint seed allocation (Tuning, Calibration, Val-A, Val-B, Frozen) | Strict anti-leakage protection & nested validation | DEC-007, DEC-012 / Final G2 |
| 2026-11-03 | Exploratory Lateral Creep explicitly labelled Unvalidated Candidate Correction | Resolves root cause of F3 without violating hard constraints | DEC-008 / Final G2 |
| 2026-11-03 | Exact 2D Quadratic TTC with CPA ($C \le 0 \implies 0, A=0 \implies \text{null}, \mathcal{D}<0 \implies \text{null}$) | Rigorous physical kinematics | DEC-009, DEC-017 / Final G2 |
| 2026-11-03 | Discrete SAT $10\text{ Hz}$ Sampling Limitations & Projected Geometry ($2.40\text{ m}$) | Rigorous physical boundary documentation | DEC-010 / Final G2 |
| 2026-11-03 | 2D Anisotropic Conformal Uncertainty Covariance Inflation ($\beta_{\text{long}}=0.50, \beta_{\text{lat}}=0.35$) | Mathematically supported 2D uncertainty | DEC-013 / Final G2 |
| 2026-11-03 | Multi-agent risk aggregated via Probabilistic Independent Union after individual clipping | Monotonic, bounded risk landscape | DEC-014, DEC-019 / Final G2 |
| 2026-11-03 | Oriented rectangular footprint lateral constraint ($|y| + W_{\text{eff}}(\psi) \le 4.70\text{ m}$) | Physical feasibility of rectangular chassis under yaw | DEC-015, DEC-018 / Final G2 |
| 2026-11-03 | Exact McNemar Power Verification ($95.40\%$) and preservation of $N=150$ | Verified exact vs asymptotic power & sensitivity | DEC-016, DEC-020 / Final G2 |
| 2026-11-03 | Conformal Score & Prediction Set Consistency via Anisotropic Mahalanobis Calibration Level Sets | Deployed set matches score level set; $\beta_{\text{long}}=0.50, \beta_{\text{lat}}=0.35$ pre-calibrated on tuning split; pointwise vs simultaneous coverage defined | DEC-021 / Final G2 Closure |
| 2026-11-03 | Episode-Level Conformal Aggregation & Inference-Time Feature Parity | Conservative max across same-class obstacles ($s_e = \max_j s_{e, j}$); non-target episodes excluded (no zero scores); independent episode count $n_e(c)$ distinguished from observation count $N_{\text{obs}}(c)$; inference inputs ($v_j(t_0), L_j$) strictly defined at query timestamp $t_0$ | DEC-022 / Final G2 Review |
| 2026-11-03 | F4 Conformal Calibration Integration Architecture | Implemented exact anisotropic Mahalanobis calibrator; finite-sample order statistic $m = \lceil(n_e+1)(1-\alpha)\rceil$; 3.50m fallback strictly marked coverage_guarantee_valid=False; 10/10 tests pass | DEC-023 / Phase 1 Step 1 |
| 2026-11-03 | Authoritative Metrics Consolidation & Independent Conformal Artifact Generation | Resolved F1 (jerk calculation), F2 (frontend fallbacks), F7 (metrics consolidation); generated independent calibration artifact across Seeds 1500–1539; 145/145 backend and 17/17 studio tests pass | DEC-024 / Phase 1 Step 2 |
| 2026-11-03 | F3 Correction Design Finalization & Governance Reaffirmation of Seed Splits | Reaffirmed 5-way disjoint split; finalized stationary penalty formulation, hypothesis weighting separation, and risk field dilation cleanup | DEC-025 / Phase 1 Step 3A |
| 2026-11-03 | F3 Correction Implementation & Validation B Benchmark Execution | Implemented stationary persistence penalty, SAT occupancy checking, risk field cleanup; executed 75 episodes across Validation B (Seeds 2005–2009); 100% completion on Scenario 5; generated `runs/val_b_manifest.json` | DEC-026 / Phase 1 Step 3B |
| 2026-11-03 | Gate G3 Step 3B Independent Evidence Verification | Completed independent audit across Checks 1–5; verified footprint containment, SAT predicted occupancy, near-miss/MRM dynamics, and seed governance; classified Step 3B as Verified with Documented Limitations (`docs/G3_VERIFICATION_REPORT.md`) | Gate G3 Verification |

## Open questions and risks
- F4 split-conformal calibration integration will require generating calibration logs across seeds 1500–1539.
- Final power calculation will be confirmed on validation data discordance before Gate G3.

## Commands actually executed
| Command | Result | Output/log path |
|---|---|---|
| `git init` | Initialized empty Git repo | Task 121 |
| `git add .; git commit -m "chore: initial baseline commit of untouched project state"; git tag baseline-v0` | Created `baseline-v0` tag | Task 128 |
| `git checkout -b research/phase-0-audit` | Switched to `research/phase-0-audit` | Task 137 |
| `python -m pytest` | 216 passed, 9 warnings in 47.09s | Task 148 |
| `cd studio; npm test` | 5 test files, 17 tests passed in 4.51s | Task 163 |
| `git add docs/...; git commit ...` | Committed baseline and revised documentation | Task 265, 309, 321, 340, 359 |

## Tests
- Baseline: Python: 216 passed; Studio: 17 passed
- Current: Python: 216 passed; Studio: 17 passed
- Failures: 0
- Skips: 0
- Deviations from baseline: 0

## Research integrity
- Existing exposed frozen results labelled exploratory: Permanently documented in SAP Section 3
- New frozen seed list disjointness verified: Mathematically proven in SAP Section 3
- SAP status: Revised v2.2 submitted for Final Gate G2 Review (`docs/SAP.md`)
- Dirty-tree status: Clean on `research/phase-0-audit`
- Run classes implemented: Specified in `docs/METRICS.md` & `docs/SAP.md`
- Metric-definition version: `2.2.0-draft` (`docs/METRICS.md`)

## Demo status
- Real engine launch: Verified working in demo bundle
- Recorded replay: Sample runs exist in `storage/runs/` and `studio/public/sample_runs/`
- Provenance: To be badged as `LIVE SIMULATION` or `RECORDED EXPERIMENT`
- Actual state-to-render correspondence: Verified
- Scalar/spatial risk labelling: Documented to show `SCALAR RISK` until Phase 3
- Playwright: E2E tests exist in `studio/e2e`
- Known demo limitations: Documented in `docs/AUDIT.md` and `docs/DECISIONS.md`

## Next exact action
1. Await user review of `docs/G3_VERIFICATION_REPORT.md` and authorization for next research phase (e.g. baseline selection on Validation A or confirmatory frozen testing Gate G4/G5).
2. **STOP** and do not access Validation A (2000–2004) or Confirmatory Frozen split (3000–3029) without explicit approval.

## Handover notes for next session
- Read standing rules (`ADAPTIVE_PATH_Execution_Package/prompts/00_STANDING_ENGINEERING_RULES.md`).
- Read this file (`docs/PROGRESS.md`).
- Independent verification for Gate G3 is complete: `docs/G3_VERIFICATION_REPORT.md`.
- All checks classified and documented: Step 3B verified with documented limitations.
- Working tree clean; all tests passing (42 unit/regression + 2 property).
- Confirmatory frozen split (Seeds 3000–3029) and Validation A (Seeds 2000–2004) remain strictly untouched.
